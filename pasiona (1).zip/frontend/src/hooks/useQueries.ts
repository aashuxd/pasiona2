import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { SubjectType } from '../backend';

interface SubmitInquiryParams {
  fullName: string;
  emailAddress: string;
  subject: SubjectType;
  message: string;
}

export function useSubmitInquiry() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ fullName, emailAddress, subject, message }: SubmitInquiryParams) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.submitInquiry(fullName, emailAddress, subject, message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inquiries'] });
    },
  });
}
