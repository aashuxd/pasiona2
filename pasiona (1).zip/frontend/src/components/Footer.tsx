import { SiInstagram, SiPinterest, SiLinkedin } from 'react-icons/si';

const navLinks = [
  { label: 'Story', href: '#story' },
  { label: 'Collections', href: '#collections' },
  { label: 'Lookbook', href: '#lookbook' },
  { label: 'Values', href: '#values' },
  { label: 'Contact', href: '#contact' },
];

const socialLinks = [
  { icon: SiInstagram, label: 'Instagram', href: '#' },
  { icon: SiPinterest, label: 'Pinterest', href: '#' },
  { icon: SiLinkedin, label: 'LinkedIn', href: '#' },
];

export default function Footer() {
  const year = new Date().getFullYear();
  const appId = encodeURIComponent(typeof window !== 'undefined' ? window.location.hostname : 'pasiona');

  const handleNavClick = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-charcoal border-t border-border">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 items-start">
          {/* Brand */}
          <div>
            <h2 className="font-serif text-4xl tracking-[0.3em] text-champagne uppercase mb-4">
              Pasiona
            </h2>
            <p className="font-serif italic text-muted-foreground text-sm mb-6">
              Where Heritage Meets Couture
            </p>
            <span className="gold-divider block mb-6" />
            <p className="font-sans text-xs leading-relaxed text-muted-foreground max-w-xs">
              A Florentine maison dedicated to the art of bespoke dressing. Est. 1987.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <p className="font-sans text-xs tracking-[0.3em] uppercase text-gold mb-8">Navigation</p>
            <nav className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="font-sans text-sm text-muted-foreground hover:text-gold transition-colors duration-300 text-left tracking-wide"
                >
                  {link.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Social & Contact */}
          <div>
            <p className="font-sans text-xs tracking-[0.3em] uppercase text-gold mb-8">Follow Pasiona</p>
            <div className="flex gap-6 mb-10">
              {socialLinks.map(({ icon: Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="text-muted-foreground hover:text-gold transition-colors duration-300"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
            <p className="font-sans text-xs tracking-[0.2em] uppercase text-gold mb-2">Atelier</p>
            <p className="font-sans text-sm text-muted-foreground">Florence, Italy</p>
            <p className="font-sans text-sm text-muted-foreground mt-1">maison@pasiona.com</p>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-border">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-sans text-xs text-muted-foreground tracking-wide">
            © {year} Pasiona. All rights reserved.
          </p>
          <p className="font-sans text-xs text-muted-foreground">
            Built with{' '}
            <span className="text-gold">♥</span>{' '}
            using{' '}
            <a
              href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${appId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gold hover:text-gold-light transition-colors duration-300"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
