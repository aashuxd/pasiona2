import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

const collections = [
  {
    id: 'la-notte',
    name: 'La Notte',
    subtitle: 'Evening Couture',
    description:
      'Conceived for the hours after dusk, La Notte is a celebration of drama and desire. Midnight silhouettes, hand-beaded embellishments, and the deepest of velvets define this collection for those who command every room they enter.',
    image: '/assets/generated/collection-la-notte.dim_800x1000.png',
  },
  {
    id: 'primavera',
    name: 'Primavera',
    subtitle: 'Resort Collection',
    description:
      'Inspired by the first light of a Mediterranean spring, Primavera flows with effortless grace. Ivory linens, blush silks, and hand-painted florals capture the luminous beauty of the Italian Riviera at its most serene.',
    image: '/assets/generated/collection-primavera.dim_800x1000.png',
  },
  {
    id: 'essenza',
    name: 'Essenza',
    subtitle: 'Signature Tailoring',
    description:
      'The purest expression of the Pasiona philosophy. Essenza strips away the superfluous to reveal the extraordinary within restraint — structured silhouettes, impeccable tailoring, and fabrics sourced from the finest mills in Europe.',
    image: '/assets/generated/collection-essenza.dim_800x1000.png',
  },
];

function CollectionCard({ collection, index }: { collection: typeof collections[0]; index: number }) {
  const { ref, isVisible } = useScrollFadeIn();

  return (
    <article
      ref={ref as React.RefObject<HTMLElement>}
      className={`group relative overflow-hidden cursor-pointer transition-all duration-1000 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${index * 150}ms` }}
    >
      {/* Image */}
      <div className="relative overflow-hidden aspect-[4/5]">
        <img
          src={collection.image}
          alt={collection.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-500" />

        {/* Gold accent line on hover */}
        <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold group-hover:w-full transition-all duration-500" />
      </div>

      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 p-8">
        <p className="font-sans text-xs tracking-[0.3em] uppercase text-gold mb-2">{collection.subtitle}</p>
        <h3 className="font-serif text-3xl text-champagne mb-3">{collection.name}</h3>
        <p className="font-sans text-xs leading-relaxed text-champagne/60 mb-6 max-w-xs opacity-0 group-hover:opacity-100 transition-opacity duration-500 translate-y-2 group-hover:translate-y-0">
          {collection.description}
        </p>
        <div className="flex items-center gap-3 text-gold">
          <span className="font-sans text-xs tracking-[0.2em] uppercase">Discover</span>
          <span className="block w-6 h-px bg-gold group-hover:w-10 transition-all duration-300" />
        </div>
      </div>
    </article>
  );
}

export default function CollectionsSection() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollFadeIn();

  return (
    <section id="collections" className="py-32 bg-charcoal-mid">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div
          ref={headerRef as React.RefObject<HTMLDivElement>}
          className={`text-center mb-20 transition-all duration-1000 ${headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <p className="font-sans text-xs tracking-[0.3em] uppercase text-gold mb-4">Curated for the Discerning</p>
          <h2 className="font-serif text-[clamp(2.5rem,5vw,4rem)] text-champagne mb-6">
            Featured Collections
          </h2>
          <div className="flex items-center justify-center gap-4">
            <span className="block w-12 h-px bg-gold/40" />
            <span className="text-gold/40 text-xs">✦</span>
            <span className="block w-12 h-px bg-gold/40" />
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {collections.map((collection, index) => (
            <CollectionCard key={collection.id} collection={collection} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
