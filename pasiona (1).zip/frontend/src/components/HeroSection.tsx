import { useEffect, useState } from 'react';

export default function HeroSection() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToCollections = () => {
    const el = document.querySelector('#collections');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative w-full h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/assets/generated/hero-bg.dim_1920x1080.png"
          alt="Pasiona hero"
          className="w-full h-full object-cover object-center"
          onLoad={() => setLoaded(true)}
        />
        {/* Multi-layer overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/70 via-charcoal/40 to-charcoal/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal/50 via-transparent to-charcoal/30" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        {/* Pre-title */}
        <p
          className={`font-sans text-xs tracking-[0.5em] uppercase text-gold mb-6 transition-all duration-1000 delay-300 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          Maison de Couture
        </p>

        {/* Brand Name */}
        <h1
          className={`font-serif text-[clamp(4rem,12vw,9rem)] leading-none tracking-[0.15em] text-champagne uppercase mb-6 transition-all duration-1000 delay-500 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          Pasiona
        </h1>

        {/* Divider */}
        <div
          className={`flex items-center justify-center gap-4 mb-8 transition-all duration-1000 delay-700 ${
            loaded ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <span className="block w-16 h-px bg-gold" />
          <span className="text-gold text-xs">✦</span>
          <span className="block w-16 h-px bg-gold" />
        </div>

        {/* Tagline */}
        <p
          className={`font-serif italic text-[clamp(1.1rem,3vw,1.75rem)] text-champagne/80 tracking-wide mb-12 transition-all duration-1000 delay-700 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          Where Heritage Meets Couture
        </p>

        {/* CTA */}
        <button
          onClick={scrollToCollections}
          className={`group inline-flex items-center gap-3 font-sans text-xs tracking-[0.3em] uppercase text-champagne border border-gold/60 px-10 py-4 hover:bg-gold hover:text-charcoal hover:border-gold transition-all duration-400 transition-all duration-1000 delay-1000 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          Explore the Collection
          <span className="block w-4 h-px bg-current group-hover:w-6 transition-all duration-300" />
        </button>
      </div>

      {/* Scroll indicator */}
      <div
        className={`absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 transition-all duration-1000 delay-1200 ${
          loaded ? 'opacity-60' : 'opacity-0'
        }`}
      >
        <span className="font-sans text-[10px] tracking-[0.3em] uppercase text-champagne/60">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-champagne/60 to-transparent animate-pulse" />
      </div>
    </section>
  );
}
