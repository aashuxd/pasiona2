import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

const lookbookEntries = [
  {
    id: 1,
    title: 'The Artisan\'s Touch',
    caption: 'Hand-stitched ivory silk lapels — each stitch placed with the precision of a master craftsman.',
    image: '/assets/generated/lookbook-1.dim_900x1100.png',
    size: 'tall',
  },
  {
    id: 2,
    title: 'Nocturne in Gold',
    caption: 'A full-length gown with cascading gold accents against dark marble — the embodiment of La Notte.',
    image: '/assets/generated/lookbook-2.dim_900x1100.png',
    size: 'tall',
  },
  {
    id: 3,
    title: 'The Palette',
    caption: 'Champagne, obsidian, and ivory — the Pasiona color story laid bare in fabric and form.',
    image: '/assets/generated/lookbook-3.dim_900x900.png',
    size: 'square',
  },
  {
    id: 4,
    title: 'Architecture of Dress',
    caption: 'Structured tailoring meets geometric shadow — the Essenza suit in its natural habitat.',
    image: '/assets/generated/lookbook-4.dim_900x1100.png',
    size: 'tall',
  },
];

function LookbookCard({ entry, delay = 0 }: { entry: typeof lookbookEntries[0]; delay?: number }) {
  const { ref, isVisible } = useScrollFadeIn();

  return (
    <article
      ref={ref as React.RefObject<HTMLElement>}
      className={`group relative overflow-hidden cursor-pointer transition-all duration-1000 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className={`relative overflow-hidden ${entry.size === 'square' ? 'aspect-square' : 'aspect-[3/4]'}`}>
        <img
          src={entry.image}
          alt={entry.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal/85 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

        {/* Content on hover */}
        <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
          <h3 className="font-serif text-xl text-champagne mb-2">{entry.title}</h3>
          <p className="font-sans text-xs leading-relaxed text-champagne/70">{entry.caption}</p>
        </div>

        {/* Always visible title bar at bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-charcoal/60 to-transparent group-hover:opacity-0 transition-opacity duration-300">
          <p className="font-sans text-xs tracking-[0.2em] uppercase text-gold">{entry.title}</p>
        </div>
      </div>
    </article>
  );
}

export default function LookbookSection() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollFadeIn();

  return (
    <section id="lookbook" className="py-32 bg-charcoal">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div
          ref={headerRef as React.RefObject<HTMLDivElement>}
          className={`mb-20 transition-all duration-1000 ${headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <div className="flex items-center gap-4 mb-6">
            <span className="block w-12 h-px bg-gold" />
            <span className="font-sans text-xs tracking-[0.3em] uppercase text-gold">Editorial</span>
          </div>
          <h2 className="font-serif text-[clamp(2.5rem,5vw,4rem)] text-champagne">
            The Lookbook
          </h2>
          <p className="font-sans text-sm text-muted-foreground mt-4 max-w-md leading-relaxed">
            A curated visual narrative — each image a chapter in the Pasiona story of beauty, craft, and intention.
          </p>
        </div>

        {/* Asymmetric Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {/* First column: tall */}
          <div className="col-span-1">
            <LookbookCard entry={lookbookEntries[0]} delay={0} />
          </div>

          {/* Second column: tall + square stacked */}
          <div className="col-span-1 flex flex-col gap-4">
            <LookbookCard entry={lookbookEntries[2]} delay={100} />
          </div>

          {/* Third column: tall */}
          <div className="col-span-1">
            <LookbookCard entry={lookbookEntries[1]} delay={200} />
          </div>

          {/* Fourth column: tall */}
          <div className="col-span-1">
            <LookbookCard entry={lookbookEntries[3]} delay={300} />
          </div>
        </div>
      </div>
    </section>
  );
}
