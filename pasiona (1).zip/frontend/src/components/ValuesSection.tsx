import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

const values = [
  {
    id: 'craftsmanship',
    numeral: 'I',
    title: 'Craftsmanship',
    description:
      'Every Pasiona garment is born from the hands of master artisans trained in the Florentine tradition. We reject the machine-made in favor of the hand-stitched, the hand-cut, and the hand-finished — because true luxury cannot be automated.',
    detail: 'Over 200 hours per garment',
  },
  {
    id: 'exclusivity',
    numeral: 'II',
    title: 'Exclusivity',
    description:
      'We produce in limited numbers by design. Each collection is a finite edition, ensuring that those who wear Pasiona are among a rare few. Our clients do not simply purchase clothing — they acquire a singular object of desire.',
    detail: 'Limited to 50 pieces per design',
  },
  {
    id: 'elegance',
    numeral: 'III',
    title: 'Elegance',
    description:
      'Elegance, for us, is not decoration — it is the absence of the unnecessary. We pursue a refined beauty that transcends seasons and trends, creating pieces that will be worn, cherished, and passed down across generations.',
    detail: 'Timeless over transient',
  },
];

function ValueCard({ value, index }: { value: typeof values[0]; index: number }) {
  const { ref, isVisible } = useScrollFadeIn();

  return (
    <article
      ref={ref as React.RefObject<HTMLElement>}
      className={`relative text-center px-8 py-12 border border-border hover:border-gold/40 transition-all duration-700 group ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${index * 200}ms` }}
    >
      {/* Roman Numeral */}
      <div className="font-serif text-7xl text-gold/10 group-hover:text-gold/20 transition-colors duration-500 leading-none mb-6 select-none">
        {value.numeral}
      </div>

      {/* Divider */}
      <div className="flex items-center justify-center gap-3 mb-8">
        <span className="block w-8 h-px bg-gold/40 group-hover:bg-gold transition-colors duration-500" />
        <span className="text-gold/40 group-hover:text-gold text-xs transition-colors duration-500">✦</span>
        <span className="block w-8 h-px bg-gold/40 group-hover:bg-gold transition-colors duration-500" />
      </div>

      {/* Title */}
      <h3 className="font-serif text-2xl text-champagne mb-6 tracking-wide">{value.title}</h3>

      {/* Description */}
      <p className="font-sans text-sm leading-relaxed text-muted-foreground mb-8">
        {value.description}
      </p>

      {/* Detail */}
      <p className="font-sans text-xs tracking-[0.2em] uppercase text-gold/60 group-hover:text-gold transition-colors duration-500">
        {value.detail}
      </p>
    </article>
  );
}

export default function ValuesSection() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollFadeIn();

  return (
    <section id="values" className="py-32 bg-charcoal-light">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div
          ref={headerRef as React.RefObject<HTMLDivElement>}
          className={`text-center mb-20 transition-all duration-1000 ${headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <p className="font-sans text-xs tracking-[0.3em] uppercase text-gold mb-4">The Pasiona Philosophy</p>
          <h2 className="font-serif text-[clamp(2.5rem,5vw,4rem)] text-champagne mb-6">
            Our Pillars
          </h2>
          <div className="flex items-center justify-center gap-4">
            <span className="block w-12 h-px bg-gold/40" />
            <span className="text-gold/40 text-xs">✦</span>
            <span className="block w-12 h-px bg-gold/40" />
          </div>
        </div>

        {/* Values Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-0 md:gap-px bg-border">
          {values.map((value, index) => (
            <div key={value.id} className="bg-charcoal-light">
              <ValueCard value={value} index={index} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
