import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

export default function BrandStorySection() {
  const { ref: textRef, isVisible: textVisible } = useScrollFadeIn();
  const { ref: imageRef, isVisible: imageVisible } = useScrollFadeIn();

  return (
    <section id="story" className="py-32 bg-charcoal">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Label */}
        <div className="flex items-center gap-4 mb-20">
          <span className="block w-12 h-px bg-gold" />
          <span className="font-sans text-xs tracking-[0.3em] uppercase text-gold">Our Story</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Text Side */}
          <div
            ref={textRef as React.RefObject<HTMLDivElement>}
            className={`transition-all duration-1000 ${textVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          >
            <h2 className="font-serif text-[clamp(2.5rem,5vw,4rem)] leading-tight text-champagne mb-8">
              Born from the<br />
              <em className="text-gold">Soul of Italy</em>
            </h2>

            <span className="gold-divider mb-10 block" />

            <div className="space-y-6 text-muted-foreground font-sans font-light leading-relaxed text-[0.95rem]">
              <p>
                Pasiona was founded in the sun-drenched ateliers of Florence, where centuries of artisanal tradition meet the restless spirit of modern couture. Our founders, trained under the great Florentine masters, believed that true luxury is not worn — it is felt.
              </p>
              <p>
                Every garment that bears the Pasiona name is the result of hundreds of hours of meticulous handwork. From the first sketch to the final stitch, our artisans pour their heritage into each creation, ensuring that what you receive is not merely clothing, but a living testament to the art of dressing.
              </p>
              <p>
                We do not follow trends. We set the standard for those who understand that elegance is a language spoken in silence — in the drape of a lapel, the weight of a fabric, the precision of a seam.
              </p>
            </div>

            <div className="mt-12 flex items-center gap-6">
              <div className="text-center">
                <p className="font-serif text-4xl text-gold">1987</p>
                <p className="font-sans text-xs tracking-[0.2em] uppercase text-muted-foreground mt-1">Founded</p>
              </div>
              <div className="w-px h-12 bg-border" />
              <div className="text-center">
                <p className="font-serif text-4xl text-gold">38+</p>
                <p className="font-sans text-xs tracking-[0.2em] uppercase text-muted-foreground mt-1">Years of Craft</p>
              </div>
              <div className="w-px h-12 bg-border" />
              <div className="text-center">
                <p className="font-serif text-4xl text-gold">12</p>
                <p className="font-sans text-xs tracking-[0.2em] uppercase text-muted-foreground mt-1">Collections</p>
              </div>
            </div>
          </div>

          {/* Image Side */}
          <div
            ref={imageRef as React.RefObject<HTMLDivElement>}
            className={`relative transition-all duration-1000 delay-300 ${imageVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          >
            <div className="relative">
              {/* Decorative border offset */}
              <div className="absolute -top-4 -right-4 w-full h-full border border-gold/20" />
              <img
                src="/assets/generated/brand-story.dim_1200x800.png"
                alt="Pasiona atelier"
                className="w-full h-auto object-cover relative z-10"
              />
              {/* Caption */}
              <div className="absolute bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-charcoal/80 to-transparent p-6">
                <p className="font-serif italic text-champagne/70 text-sm">
                  "Craftsmanship is the poetry of the hands."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
