import { useState } from 'react';
import { useScrollFadeIn } from '../hooks/useScrollFadeIn';
import { useSubmitInquiry } from '../hooks/useQueries';
import { SubjectType } from '../backend';

const subjectOptions = [
  { value: SubjectType.generalInquiry, label: 'General Inquiry' },
  { value: SubjectType.bespokeOrder, label: 'Bespoke Order' },
  { value: SubjectType.pressMedia, label: 'Press & Media' },
  { value: SubjectType.partnership, label: 'Partnership' },
];

interface FormState {
  fullName: string;
  emailAddress: string;
  subject: SubjectType | '';
  message: string;
}

interface FormErrors {
  fullName?: string;
  emailAddress?: string;
  subject?: string;
  message?: string;
}

export default function ContactSection() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollFadeIn();
  const { ref: formRef, isVisible: formVisible } = useScrollFadeIn();

  const [form, setForm] = useState<FormState>({
    fullName: '',
    emailAddress: '',
    subject: '',
    message: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  const submitInquiry = useSubmitInquiry();

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!form.fullName.trim()) newErrors.fullName = 'Full name is required.';
    if (!form.emailAddress.trim()) {
      newErrors.emailAddress = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.emailAddress)) {
      newErrors.emailAddress = 'Please enter a valid email address.';
    }
    if (!form.subject) newErrors.subject = 'Please select a subject.';
    if (!form.message.trim()) newErrors.message = 'Message is required.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    if (!form.subject) return;

    try {
      await submitInquiry.mutateAsync({
        fullName: form.fullName,
        emailAddress: form.emailAddress,
        subject: form.subject as SubjectType,
        message: form.message,
      });
      setSubmitted(true);
      setForm({ fullName: '', emailAddress: '', subject: '', message: '' });
    } catch {
      // Error handled via mutation state
    }
  };

  const handleChange = (field: keyof FormState, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  return (
    <section id="contact" className="py-32 bg-charcoal">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
          {/* Left: Info */}
          <div
            ref={headerRef as React.RefObject<HTMLDivElement>}
            className={`transition-all duration-1000 ${headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          >
            <div className="flex items-center gap-4 mb-8">
              <span className="block w-12 h-px bg-gold" />
              <span className="font-sans text-xs tracking-[0.3em] uppercase text-gold">Inquiries</span>
            </div>

            <h2 className="font-serif text-[clamp(2.5rem,5vw,4rem)] text-champagne leading-tight mb-8">
              Begin Your<br />
              <em className="text-gold">Pasiona Journey</em>
            </h2>

            <p className="font-sans text-sm leading-relaxed text-muted-foreground mb-12 max-w-sm">
              Whether you seek a bespoke commission, wish to discuss a partnership, or simply desire to know more about our world — we welcome your correspondence with the same care we bring to every garment.
            </p>

            <div className="space-y-6">
              <div>
                <p className="font-sans text-xs tracking-[0.2em] uppercase text-gold mb-1">Atelier</p>
                <p className="font-sans text-sm text-muted-foreground">Via della Vigna Nuova, Florence, Italy</p>
              </div>
              <div>
                <p className="font-sans text-xs tracking-[0.2em] uppercase text-gold mb-1">Correspondence</p>
                <p className="font-sans text-sm text-muted-foreground">maison@pasiona.com</p>
              </div>
              <div>
                <p className="font-sans text-xs tracking-[0.2em] uppercase text-gold mb-1">Appointments</p>
                <p className="font-sans text-sm text-muted-foreground">By private arrangement only</p>
              </div>
            </div>
          </div>

          {/* Right: Form */}
          <div
            ref={formRef as React.RefObject<HTMLDivElement>}
            className={`transition-all duration-1000 delay-300 ${formVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          >
            {submitted ? (
              <div className="border border-gold/30 p-12 text-center">
                <div className="flex items-center justify-center gap-4 mb-6">
                  <span className="block w-8 h-px bg-gold" />
                  <span className="text-gold text-lg">✦</span>
                  <span className="block w-8 h-px bg-gold" />
                </div>
                <h3 className="font-serif text-3xl text-champagne mb-4">Thank You</h3>
                <p className="font-sans text-sm text-muted-foreground leading-relaxed">
                  Your inquiry has been received. A member of the Pasiona maison will respond to you with the discretion and care your correspondence deserves.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-8 font-sans text-xs tracking-[0.2em] uppercase text-gold border border-gold/40 px-8 py-3 hover:bg-gold hover:text-charcoal transition-all duration-300"
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-10" noValidate>
                {/* Full Name */}
                <div>
                  <label className="block font-sans text-xs tracking-[0.2em] uppercase text-gold/70 mb-3">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={form.fullName}
                    onChange={(e) => handleChange('fullName', e.target.value)}
                    placeholder="Your full name"
                    className="luxury-input"
                  />
                  {errors.fullName && (
                    <p className="font-sans text-xs text-destructive mt-2">{errors.fullName}</p>
                  )}
                </div>

                {/* Email */}
                <div>
                  <label className="block font-sans text-xs tracking-[0.2em] uppercase text-gold/70 mb-3">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={form.emailAddress}
                    onChange={(e) => handleChange('emailAddress', e.target.value)}
                    placeholder="your@email.com"
                    className="luxury-input"
                  />
                  {errors.emailAddress && (
                    <p className="font-sans text-xs text-destructive mt-2">{errors.emailAddress}</p>
                  )}
                </div>

                {/* Subject */}
                <div>
                  <label className="block font-sans text-xs tracking-[0.2em] uppercase text-gold/70 mb-3">
                    Subject
                  </label>
                  <select
                    value={form.subject}
                    onChange={(e) => handleChange('subject', e.target.value)}
                    className="luxury-input appearance-none cursor-pointer"
                  >
                    <option value="" disabled>Select a subject</option>
                    {subjectOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                  {errors.subject && (
                    <p className="font-sans text-xs text-destructive mt-2">{errors.subject}</p>
                  )}
                </div>

                {/* Message */}
                <div>
                  <label className="block font-sans text-xs tracking-[0.2em] uppercase text-gold/70 mb-3">
                    Message
                  </label>
                  <textarea
                    value={form.message}
                    onChange={(e) => handleChange('message', e.target.value)}
                    placeholder="Your message..."
                    rows={5}
                    className="luxury-input resize-none"
                  />
                  {errors.message && (
                    <p className="font-sans text-xs text-destructive mt-2">{errors.message}</p>
                  )}
                </div>

                {/* Submit Error */}
                {submitInquiry.isError && (
                  <p className="font-sans text-xs text-destructive">
                    {submitInquiry.error instanceof Error
                      ? submitInquiry.error.message.includes('already submitted')
                        ? 'An inquiry has already been submitted from this account.'
                        : 'An error occurred. Please try again.'
                      : 'An error occurred. Please try again.'}
                  </p>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={submitInquiry.isPending}
                  className="group w-full flex items-center justify-center gap-3 font-sans text-xs tracking-[0.3em] uppercase text-champagne border border-gold/60 px-10 py-5 hover:bg-gold hover:text-charcoal hover:border-gold transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitInquiry.isPending ? (
                    <>
                      <span className="inline-block w-3 h-3 border border-current border-t-transparent rounded-full animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      Submit Inquiry
                      <span className="block w-4 h-px bg-current group-hover:w-6 transition-all duration-300" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
