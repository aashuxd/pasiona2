import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Inquiry {
    subject: SubjectType;
    fullName: string;
    sender: Principal;
    message: string;
    emailAddress: string;
}
export enum SubjectType {
    bespokeOrder = "bespokeOrder",
    partnership = "partnership",
    generalInquiry = "generalInquiry",
    pressMedia = "pressMedia"
}
export interface backendInterface {
    getAllInquiries(): Promise<Array<Inquiry>>;
    submitInquiry(fullName: string, emailAddress: string, subject: SubjectType, message: string): Promise<void>;
}
