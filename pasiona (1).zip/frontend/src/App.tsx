import Navigation from './components/Navigation';
import HeroSection from './components/HeroSection';
import BrandStorySection from './components/BrandStorySection';
import CollectionsSection from './components/CollectionsSection';
import LookbookSection from './components/LookbookSection';
import ValuesSection from './components/ValuesSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-charcoal">
      <Navigation />

      <main>
        <HeroSection />

        <section id="story">
          <BrandStorySection />
        </section>

        <section id="collections">
          <CollectionsSection />
        </section>

        <section id="lookbook">
          <LookbookSection />
        </section>

        <section id="values">
          <ValuesSection />
        </section>

        <section id="contact">
          <ContactSection />
        </section>
      </main>

      <Footer />
    </div>
  );
}
