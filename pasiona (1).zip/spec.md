# Specification

## Summary
**Goal:** Add a subtle "Built with ♥ using caffeine.ai" attribution line to the site footer.

**Planned changes:**
- Add "Built with ♥ using caffeine.ai" text to the footer's bottom bar, near the existing copyright line
- Style the attribution with small, muted champagne or gold-toned text to complement the luxury dark theme

**User-visible outcome:** The footer bottom bar displays a subtle "Built with ♥ using caffeine.ai" attribution alongside the copyright line, consistent with the existing luxury dark aesthetic.
